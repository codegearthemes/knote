<?php 
// Silence is golden.
